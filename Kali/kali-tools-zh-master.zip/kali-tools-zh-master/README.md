# Kali Linux Tools 中文說明書
> kali linux 工具使用（中文版）

![img](https://github.com/louchaooo/kali-tools-zh/blob/master/kalitools/image/kali_page.png)
